# validation.md

Problem: Remediate the c_to_f implementation in units.py so it computes the correct Celsius-to-Fahrenheit conversion for all numeric inputs, including negatives, while preserving the already correct collapse_spaces implementation in text.py and the immutable seeded test suite.

All acceptance criteria traced to passing evidence in verification.md.

## Owner waivers

- None

SIGN-OFF: pending human decision via `python3 -m pipeline.approvals validate approve|deny "reason"`
