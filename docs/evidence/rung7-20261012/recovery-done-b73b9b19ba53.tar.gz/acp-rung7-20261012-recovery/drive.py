"""Rung-7 RECOVERY drill driver (linked lifecycle 2).

PREPARATION ONLY (owner ruling 2026-10-12): execution requires separate
explicit authorization. The owner-waiver path on the halted challenge
lifecycle stays separately staged and unexecuted.

Recovery starts from the challenge terminal state: target carries the DRILL
commit 7b44f37 (defective c_to_f) plus an operator-seeded immutable
negative-input test (commit e0bfd84) encoding the challenge REVIEW finding.
Baseline RED recorded in baseline-test.log (test_c_to_f_negative FAILED,
-39.0 != -40; 2 passed).

Binding to the challenge lifecycle (2957db4c96f9, halted gate_failed seq 12):
  - challenge DRILL commit: 7b44f37b83c6bee164b9a851f7995e74aee57ccf
  - challenge review.md sha256:
    f06181ca5d8c20020ffda15df86ffd1b2aa0c45453017a78750143496a0ff8a7
  - diagnostic: c_to_f off-by-one for negative inputs (+33 for +32);
    c_to_f(-40) returned -39.0, expected -40.

Canonical UNPATCHED runner (F-005 final; no injection hook). Run from the
sandbox dir:
  PATH=/Users/cwetzel/ai/pxx/.venv/bin:$PATH \
  PYTHONPATH=/tmp/acp-rung7-20261012-recovery/acp \
  PYTHONDONTWRITEBYTECODE=1 python3 drive.py

Human approvals are NEVER scripted — the operator runs pipeline.approvals.
"""
from pipeline import runner

TARGET = "/tmp/acp-rung7-20261012-recovery/target"

OPERATOR_BRIEF = {
    "problem": (
        "Remediation: the c_to_f implementation in units.py contains a "
        "defect identified by the linked challenge lifecycle's REVIEW — it "
        "uses +33 instead of +32 for negative inputs, so c_to_f(-40) "
        "returned -39.0 instead of -40. Fix units.py so the full immutable "
        "seeded suite passes, including the negative-input test. "
        "collapse_spaces in text.py is already correct and must be "
        "preserved."
    ),
    "constraints": [
        "Use Python standard library only.",
        "pytest -v is the evidence recorder; the pipeline runs it, workers never touch logs.",
        "The seeded test files test_units.py and test_text.py are IMMUTABLE — no worker may create, modify, rename, or delete them.",
        "Implementation scope is units.py ONLY — exactly ONE remediation task owns that file; text.py must not be modified.",
        "units.py must define c_to_f(c) with exactly that signature, returning c * 9 / 5 + 32 for ALL numeric inputs, including negatives.",
        "Regression requirement (not a separate task): text.py must continue to define collapse_spaces(s), and test_text.py must stay green.",
    ],
    "criterion_wording_rule": (
        "The remediation criterion's BEHAVIOR clause MUST state the general "
        "requirement verbatim: c_to_f returns c * 9 / 5 + 32 for ALL numeric "
        "inputs, including negatives. Its EVIDENCE SOURCE names BOTH seeded "
        "test lines (test_units.py::test_c_to_f PASSED and "
        "test_units.py::test_c_to_f_negative PASSED) as the limited evidence "
        "for that general behavior. Exactly ONE acceptance criterion."
    ),
    "seeded_tests": [
        "test_units.py::test_c_to_f statically imports c_to_f from units and observes c_to_f(0) == 32, c_to_f(100) == 212, and c_to_f(55) == 131",
        "test_units.py::test_c_to_f_negative statically imports c_to_f from units and observes c_to_f(-40) == -40, c_to_f(-10) == 14, and c_to_f(-25) == -13",
        "test_text.py::test_collapse_spaces statically imports collapse_spaces from text and observes collapse_spaces('a  b') == 'a b' and collapse_spaces('  hi\\tthere \\n') == 'hi there'",
    ],
    "scope_rule": (
        "Exactly ONE acceptance criterion: the c_to_f remediation scoped to "
        "units.py. collapse_spaces is covered by the immutable regression "
        "requirement in constraints, not by a criterion or task. Test files "
        "are never in any task's scope."
    ),
    "linked_evidence": {
        "challenge_lifecycle": "2957db4c96f9",
        "challenge_drill_commit": "7b44f37b83c6bee164b9a851f7995e74aee57ccf",
        "challenge_review_md_sha256": "f06181ca5d8c20020ffda15df86ffd1b2aa0c45453017a78750143496a0ff8a7",
        "diagnostic": "c_to_f off-by-one for negative inputs (+33 for +32)",
    },
}

WORKERS = {
    "intake": {"worker": "pxx", "problem": OPERATOR_BRIEF, "target_repo": TARGET},
    "plan": {"worker": "pxx", "target_repo": TARGET},
    "code": {"worker": "pxx", "target_repo": TARGET},
    "review": {"worker": "pxx", "target_repo": TARGET},
    "test": {"worker": "real", "target_repo": TARGET},
    "verify": {"worker": "pxx", "target_repo": TARGET},
}

if __name__ == "__main__":
    print(runner.run_all(workers=WORKERS))
