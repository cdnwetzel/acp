# Rung-7 path (c2′) v2 — VALIDATE visibility, sandbox scaffold manifest (staged 2026-10-12)

Owner authorization: staging through `gate_open:intake` only. No waiver,
resume, or later-stage execution authorized. Canonical repo untouched.

## Qualification scope (explicit)

Deterministic waiver propagation, VALIDATE content checking, and
receipt-authority reconciliation — under the **canonical** runner, gates,
and `waiver_proof.py`. NOT model reliability or behavioral correctness.

## Canonical files (byte-identical to /Users/cwetzel/ai/acp @ 0c50e42)

| File | sha256 |
|---|---|
| `acp/pipeline/runner.py` | `fb8742db589c322c359bd26b4bcd04e212657d81f3f20a740d563e8825516b07` |
| `acp/pipeline/gates.py` | `73ea192b84460e9a0702d059815b246e5f621eab92069bb373fc6906e3be602f` |
| `acp/pipeline/waiver_proof.py` | `8f454a61ea43a5b9305d31b676b0bce50fc18ed6421540598f1b4aa13893d88d` |
| `acp/endpoints.json` | `6d72585746ac48f6d28e17edd3d0597b01f125b18cdc09c4e39604670aed53cc` |

(All other pipeline files copied unchanged from canonical at the same HEAD.)

## Sandbox-only deltas

| File | sha256 | Note |
|---|---|---|
| `acp/pipeline/phases/review.py` | `552cb86099c714acb1757a61bdeab9d64871aed69cb44fc2bbd4f42f5baac760` | adds `worker="controlled"` branch only; diff: `review.py.sandbox-diff.patch` (`5ced689f…`) |
| `acp/pipeline/phases/verify.py` | `883cc5553c489c4f6f793c8dcf8f0edecdeb8b1435c7495ac4346354f5e20c24` | adds `worker="controlled"` PASS branch only; diff: `verify.py.sandbox-diff.patch` (`3ff684b1…`) |
| `drive.py` | `6e7ead6736fb141b65a6a30d522b195ceafa88110e06dbdbb7bd01b3b870b003` | review/verify workers = `controlled`; intake/plan/code live (T5810 `:8004`); test real |
| `baseline-test.log` | `b3fdadbc61abffaf968791a8805615ea96a15328e2654653632bc9123eaaf06a` | baseline red: exit 2, collection errors |

Target: fresh repo, seeded tests byte-identical to the rung-7 immutable set
(`test_units.py` `68654d9a…`, `test_text.py` `88c9e423…`), seed commit
`bca1d28`, clean tree.

## Pre-registered controlled outputs (fixed before any gate decision)

**Controlled REVIEW finding** (exact normalized line, on the task owning
`units.py`; all other tasks get `issue: none — RESOLVED (diff satisfies the
criterion as written)`):

> issue: seeded test coverage is limited to c_to_f inputs 0, 55, and 100;
> behavior at all other numeric inputs is unverified by the recorded
> evidence; no defect is asserted in the implementation itself — OPEN:
> AC-1 states a general requirement for all numeric inputs including
> negatives, while the recorded test.log evidences only the three seeded
> cases

Pre-registered finding_sha256 (TASK-1): `bfeaa1e336526e6189a28a4fc8b506124b37fcae82a9ca5982771c8b3f04ccec`
(TASK-2 RESOLVED line: `ceb07a0cfed44b5dd58251a5b7adea48da2d4f8861985e2890ecfa3fb2e53cfd`)

This is a true statement about the immutable seeded suite, independent of
what CODE produces. It asserts NO defect. The waiver's legitimacy comes
from the owner's reason (scope ruling on limited evidence), not from any
model judgment.

**Synthetic VERIFY PASS output**: deterministic function of
`artifacts/intake.json` — one PASS row per criterion with byte-exact
criterion cells, evidence cell `controlled drill declaration (synthetic, no
model call)`, and Limitations stating (a) CONTROLLED DRILL OUTPUT — not a
model judgment, PASS verdicts are synthetic evidence asserting nothing
about conformance; (b) TEST covers only the seeded cases; (c) the waived
REVIEW finding stands unresolved. Artifact header and envelope record carry
the same label.

## Preflight demonstration (2026-10-12, scratch dir, CANONICAL gates loaded
by path from /Users/cwetzel/ai/acp)

1. Controlled REVIEW artifact → canonical `gate_review` (no receipt)
   **halted**: `GateError: explicitly OPEN issue: issue: seeded test
   coverage is limited…` ✓
2. Controlled VERIFY artifact → canonical `gate_verify` returned **True**
   (format + byte-exact traceability checks pass) ✓
3. Finding hashes above computed with the canonical `finding_sha256` ✓
