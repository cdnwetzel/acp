"""Rung-7 path (c2') v2 drill driver — VALIDATE visibility of a waiver.

Owner authorization (2026-10-12): sandbox staging and execution to
gate_open:intake ONLY; every gate decision is Chris's.

Design (docs/rung7-c2-validate-visibility-design-20261012.md, v2):
deterministic controlled REVIEW (one pre-registered OPEN finding — a true
statement about the immutable seeded suite) and controlled VERIFY (PASS,
synthetic evidence, labeled). Qualification is limited to deterministic
waiver propagation, VALIDATE content checking, and receipt-authority
reconciliation under the CANONICAL runner, gates, and waiver_proof.py —
NOT model reliability or behavioral correctness.

Run from the sandbox dir with:
  PATH=/Users/cwetzel/ai/pxx/.venv/bin:$PATH \
  PYTHONPATH=/tmp/acp-rung7-20261012-c2p-validate-visibility/acp \
  PYTHONDONTWRITEBYTECODE=1 python3 drive.py

Human approvals are NEVER scripted — the operator runs pipeline.approvals.
"""
from pipeline import runner

TARGET = "/tmp/acp-rung7-20261012-c2p-validate-visibility/target"

OPERATOR_BRIEF = {
    "problem": (
        "Implement a tiny units/text toolkit. The pytest suite is already "
        "seeded by the operator and is IMMUTABLE — the implementation is "
        "outstanding and the baseline suite fails."
    ),
    "constraints": [
        "Use Python standard library only.",
        "pytest -v is the evidence recorder; the pipeline runs it, workers never touch logs.",
        "The seeded test files test_units.py and test_text.py are IMMUTABLE — no worker may create, modify, rename, or delete them.",
        "Implementation scope is units.py and text.py ONLY — one task owns each file.",
        "units.py must define c_to_f(c) with exactly that signature, returning c * 9 / 5 + 32 (Celsius to Fahrenheit) for ALL numeric inputs, including negatives.",
        "text.py must define collapse_spaces(s) with exactly that signature, returning the string with every run of whitespace collapsed to one space and ends stripped.",
    ],
    "criterion_wording_rule": (
        "The temperature acceptance criterion's BEHAVIOR clause MUST state "
        "the general requirement verbatim: c_to_f returns c * 9 / 5 + 32 "
        "for ALL numeric inputs, including negatives. Name the seeded tests "
        "separately in the criterion's EVIDENCE SOURCE as the limited "
        "evidence for that general behavior. Do not restrict the BEHAVIOR "
        "clause to the seeded cases."
    ),
    "seeded_tests": [
        "test_units.py::test_c_to_f statically imports c_to_f from units and observes c_to_f(0) == 32, c_to_f(100) == 212, and c_to_f(55) == 131",
        "test_text.py::test_collapse_spaces statically imports collapse_spaces from text and observes collapse_spaces('a  b') == 'a b' and collapse_spaces('  hi\\tthere \\n') == 'hi there'",
    ],
    "scope_rule": (
        "Acceptance-criterion SCOPE fields name implementation files only: "
        "units.py for the temperature criterion, text.py for the whitespace "
        "criterion. Test files are never in any task's scope."
    ),
}

WORKERS = {
    "intake": {"worker": "pxx", "problem": OPERATOR_BRIEF, "target_repo": TARGET},
    "plan": {"worker": "pxx", "target_repo": TARGET},
    "code": {"worker": "pxx", "target_repo": TARGET},
    "review": {"worker": "controlled", "target_repo": TARGET},
    "test": {"worker": "real", "target_repo": TARGET},
    "verify": {"worker": "controlled", "target_repo": TARGET},
}

if __name__ == "__main__":
    print(runner.run_all(workers=WORKERS))
