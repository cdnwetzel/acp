<!-- CONTROLLED DRILL OUTPUT — not a model judgment. Rung-7 path c2'
VALIDATE-visibility qualification: deterministic sandbox VERIFY.
PASS verdicts are SYNTHETIC EVIDENCE, not conformance proof. -->

# verification.md

| acceptance criterion | evidence | verdict |
|---|---|---|
| AC-1: BEHAVIOR: c_to_f returns c * 9 / 5 + 32 for ALL numeric inputs, including negatives. SUBJECT: c_to_f owned by units.py. EVIDENCE SOURCE: recorded test.log contains the line 'test_units.py::test_c_to_f PASSED' as limited evidence for that general behavior. SCOPE: units.py. | controlled drill declaration (synthetic, no model call) | PASS |
| AC-2: BEHAVIOR: collapse_spaces returns the string with every run of whitespace collapsed to one space and ends stripped. SUBJECT: collapse_spaces owned by text.py. EVIDENCE SOURCE: recorded test.log contains the line 'test_text.py::test_collapse_spaces PASSED' as limited evidence for that behavior. SCOPE: text.py. | controlled drill declaration (synthetic, no model call) | PASS |

## Limitations

- CONTROLLED DRILL OUTPUT — not a model judgment; PASS verdicts are synthetic evidence asserting nothing about conformance.
- TEST evidence covers only the seeded cases (c_to_f at 0, 55, 100; two collapse_spaces inputs), not the general numeric domain.
- The owner-waived REVIEW finding (seeded-coverage limitation) stands; this artifact does not resolve it.

