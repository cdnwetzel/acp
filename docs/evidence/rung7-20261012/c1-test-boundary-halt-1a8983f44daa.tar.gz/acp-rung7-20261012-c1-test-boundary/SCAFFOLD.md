# Rung-7 path (c1) — TEST boundary, sandbox scaffold manifest (prepared 2026-10-12)

Owner authorization: sandbox-only preparation; canonical repo untouched.
Staged to `gate_open:intake`; intake decision is Chris's.

## Sandbox-only deltas vs canonical (/Users/cwetzel/ai/acp @ 8b1148b)

| File | sha256 | Note |
|---|---|---|
| `acp/pipeline/drill.py` | `180a74a66e8a80b0dd0b8605f1cfc7ab5c81a23bf22a08bad9e5be78c82dd279` | two-mode injection; c1 uses `ACP_DRILL_INJECT_VISIBLE=1` (`if True: return c * 9 / 5 + 33`, ALL inputs; inverted proof — pytest MUST FAIL post-injection or the hook raises before any ledger write) |
| `acp/pipeline/runner.py` | `966520986b50d68019dfa188f11205bd9739ca18bbce07943b278a048cd87474` | pre-REVIEW injection hook + supersession-aware artifact-unchanged exemption (unchanged from challenge) |
| `acp/pipeline/waiver_proof.py` | `5469082df09dc94a1b12a9e6b54ab146fe037ac569b8e87c35f6d862b7b1d710` | supersession-aware manifest binding (design finding 1); canonical-orig preserved beside it |
| `acp/endpoints.json` | `c79b0ae2280ed312653b95c2744b88ff5b34e61c908d52642e44a23d65b5be33` | verify → `127.0.0.1:11435` supervised forward (operator off home LAN); original preserved at `endpoints.json.canonical-orig`; only reached if TEST unexpectedly passes |
| `drive.py` | `7198c6522f2e355634443306b1982f5bda6ef0fb4a29d92721e123a3bc49896e` | c1 driver, brief byte-equivalent to approved challenge intake |
| `baseline-test.log` | `d24893a5074010221e0ca9d20ed333b68aee17e201f3de33f0b15eb3a6d0ab00` | baseline red: exit 2, collection errors, implementation outstanding |

Target: fresh repo, seeded tests byte-identical to the challenge's
immutable tests (`test_units.py` `68654d9a…`, `test_text.py` `88c9e423…`),
seed commit `893c2cc`, clean tree.

Preflight: canonical test suite against this sandbox copy — 359 passed
(2026-10-12). One scaffold mishap preserved in the ledger: seq 1
`worker_failed` (missing sandbox-root `contracts/` on first staging run;
fixed by copying it from the challenge sandbox, byte-identical to
canonical), intake resumed and completed on the second attempt.

## Expected stop

`test gate_failed` — the waiver receipt sits validly in the ledger and is
powerless against a real TEST failure; VALIDATE never opens; no `done`.

## Qualification scope

Sandbox-assisted (supersession-aware validator + injection hook). Does
not qualify canonical behavior.
