# review.md

## TASK-1
- issue: c_to_f returns incorrect value (uses +33 instead of +32) — OPEN: the implementation does not satisfy the requirement that it return `c * 9 / 5 + 32` for all numeric inputs, including negatives.

## TASK-2
- issue: none — RESOLVED (diff satisfies the criterion)
