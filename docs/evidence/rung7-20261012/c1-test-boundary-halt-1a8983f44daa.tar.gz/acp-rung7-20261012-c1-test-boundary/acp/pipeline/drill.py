"""Sandbox-only injection with explicit ledger supersession — TWO modes.

Rung-7 boundary drills (owner-authorized preparation 2026-10-12; design
docs/rung7-bc-execution-design-20261012.md). Canonical pipeline is never
modified; this module exists only in sandbox copies. Every injection is a
ledgered `drill_inject` event with the superseded manifest hash — evidence
boundaries stay intact (rung-6 pattern, carried forward).

Mode ACP_DRILL_INJECT_REVIEW=1 (carried from path (a), unused in c1):
  test-INVISIBLE defect — c_to_f off-by-one for NEGATIVE inputs (+33 for
  +32). pytest MUST PASS post-injection or the hook raises and nothing is
  ledgered.

Mode ACP_DRILL_INJECT_VISIBLE=1 (path c1 — TEST boundary):
  test-VISIBLE defect — `if True: return c * 9 / 5 + 33` shadows ALL
  inputs. INVERTED proof: pytest MUST FAIL post-injection or the hook
  raises and nothing is ledgered. The waiver receipt must prove powerless
  against a real TEST failure (F-005 qualification boundary).
"""
import hashlib
import json
import os
import subprocess

MANIFEST = "artifacts/diff/manifest.json"
TARGET_FILE = "units.py"
ANCHOR = "def c_to_f(c):"

MODES = {
    "ACP_DRILL_INJECT_REVIEW": {
        "mark": "if c < 0:",
        "forge": ANCHOR + "\n    if c < 0:\n        return c * 9 / 5 + 33\n",
        "expect_pytest": 0,
        "defect_class": "c_to_f off-by-one for negative inputs (+33 for +32)",
        "test_case": "seeded tests exercise 0/55/100 only (invisible)",
    },
    "ACP_DRILL_INJECT_VISIBLE": {
        "mark": "if True:",
        "forge": ANCHOR + "\n    if True:\n        return c * 9 / 5 + 33\n",
        "expect_pytest": 1,
        "defect_class": "c_to_f unconditional wrong formula (+33 for +32, all inputs)",
        "test_case": "seeded tests MUST fail post-injection (visible)",
    },
}


def _sha256(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def _git(repo, *args):
    result = subprocess.run(
        ["git", *args], cwd=repo, capture_output=True, text=True, check=True)
    return result.stdout.strip()


def maybe_inject_review_challenge(target_repo):
    active = [(k, v) for k, v in MODES.items() if os.environ.get(k) == "1"]
    if not active:
        return
    if len(active) > 1:
        raise RuntimeError("conflicting drill injection modes set")
    mode_name, mode = active[0]

    from pipeline import state

    rows = state.lifecycle_rows()
    if any(r.get("event") == "drill_inject" for r in rows):
        return
    if not target_repo:
        raise RuntimeError("drill injection requires target_repo")

    manifest_sha_before = _sha256(MANIFEST)
    manifest = json.load(open(MANIFEST))
    entry = next(d for d in manifest["diffs"]
                 if TARGET_FILE in d.get("scope", []))
    task = entry["task"]
    patch_path = entry["path"]
    code_patch = patch_path + ".code"
    os.replace(patch_path, code_patch)

    units_path = os.path.join(target_repo, TARGET_FILE)
    source = open(units_path).read()
    if ANCHOR not in source or mode["mark"] in source:
        raise RuntimeError("unexpected units.py shape for drill injection")
    injected = source.replace(ANCHOR, mode["forge"], 1)
    if injected == source:
        raise RuntimeError("c_to_f signature anchor not found for injection")
    with open(units_path, "w") as f:
        f.write(injected)

    subprocess.run(["git", "add", TARGET_FILE], cwd=target_repo, check=True)
    subprocess.run(
        ["git", "commit", "-q", "-m",
         f"DRILL: forge {task} challenge ({mode['defect_class']})"],
        cwd=target_repo, check=True)
    injected_commit = _git(target_repo, "rev-parse", "HEAD")
    base_commit = json.load(open("artifacts/diff/code-state.json"))["base_commit"]

    patch = subprocess.run(
        ["git", "diff", base_commit, injected_commit, "--", TARGET_FILE],
        cwd=target_repo, capture_output=True, text=True, check=True).stdout
    with open(patch_path, "w") as f:
        f.write(patch)
    patch_sha = _sha256(patch_path)

    manifest["drill_injection"] = {
        "task": task,
        "mode": "forge-as-worker",
        "hook_mode": mode_name,
        "injected_commit": injected_commit,
        "base_commit": base_commit,
        "patch_sha256": patch_sha,
    }
    with open(MANIFEST, "w") as f:
        json.dump(manifest, f, indent=2)
        f.write("\n")
    manifest_sha_after = _sha256(MANIFEST)

    # Visibility proof, direction per mode: invisible mode requires the
    # seeded suite to PASS; visible mode requires it to FAIL. A mismatch
    # means the challenge is not the class the ledger will claim — raise
    # BEFORE any ledger write.
    result = subprocess.run(
        ["python3", "-m", "pytest", ".", "-v", "-rs", "-p", "no:cacheprovider"],
        cwd=target_repo,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        capture_output=True, text=True)
    if mode["expect_pytest"] == 0 and result.returncode != 0:
        raise RuntimeError(
            "injection was not test-invisible; pytest failed:\n"
            + result.stdout + result.stderr)
    if mode["expect_pytest"] == 1 and result.returncode == 0:
        raise RuntimeError(
            "visible injection did NOT fail the seeded suite — the TEST "
            "boundary cannot be qualified:\n" + result.stdout + result.stderr)

    state.emit(
        "code",
        "drill_inject",
        artifact=MANIFEST,
        detail={
            "task": task,
            "hook_mode": mode_name,
            "injected_commit": injected_commit,
            "base_commit": base_commit,
            "patch": patch_path,
            "patch_sha256": patch_sha,
            "supersedes_sha256": manifest_sha_before,
            "artifact_sha256": manifest_sha_after,
            "scaffold": "sandbox-only forge-as-worker injection",
            "defect_class": mode["defect_class"],
            "test_visibility": mode["test_case"],
        },
    )
