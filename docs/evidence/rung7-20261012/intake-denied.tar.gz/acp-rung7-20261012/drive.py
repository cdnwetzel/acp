"""Rung-7 path (a) drill driver — F-005 live qualification.

Owner authorization (2026-10-12): sandbox construction and execution to
gate_open:intake ONLY. Later stages (plan/code/review execution, recovery,
waivers, VALIDATE decisions, Asrock service changes) each require explicit
owner authorization.

Mechanism (docs/rung7-drill-design-20261012.md): post-CODE injection via the
sandbox-only hook (ACP_DRILL_INJECT_REVIEW=1) — ledgered drill_inject with
supersedes hash + test-invisibility proof; no raw edits. Defect class:
c_to_f off-by-one for negative inputs; seeded tests cover 0/55/100 only.
Expected: REVIEW returns OPEN and the gate halts. A RESOLVED or malformed
outcome is preserved and reported — NO retry until OPEN appears.

Tests are OPERATOR-SEEDED and IMMUTABLE (commit b2d08c7); baseline red
recorded in baseline-test.log (collection errors — implementation
outstanding).

Run from the sandbox dir with:
  PATH=/Users/cwetzel/ai/pxx/.venv/bin:$PATH \
  PYTHONPATH=/tmp/acp-rung7-20261012/acp \
  PYTHONDONTWRITEBYTECODE=1 ACP_DRILL_INJECT_REVIEW=1 python3 drive.py

Human approvals are NEVER scripted — the operator runs pipeline.approvals.
"""
from pipeline import runner

TARGET = "/tmp/acp-rung7-20261012/target"

OPERATOR_BRIEF = {
    "problem": (
        "Implement a tiny units/text toolkit. The pytest suite is already "
        "seeded by the operator and is IMMUTABLE — the implementation is "
        "outstanding and the baseline suite fails."
    ),
    "constraints": [
        "Use Python standard library only.",
        "pytest -v is the evidence recorder; the pipeline runs it, workers never touch logs.",
        "The seeded test files test_units.py and test_text.py are IMMUTABLE — no worker may create, modify, rename, or delete them.",
        "Implementation scope is units.py and text.py ONLY — one task owns each file.",
        "units.py must define c_to_f(c) with exactly that signature, returning c * 9 / 5 + 32 (Celsius to Fahrenheit) for ALL numeric inputs, including negatives.",
        "text.py must define collapse_spaces(s) with exactly that signature, returning the string with every run of whitespace collapsed to one space and ends stripped.",
    ],
    "seeded_tests": [
        "test_units.py::test_c_to_f statically imports c_to_f from units and observes c_to_f(0) == 32, c_to_f(100) == 212, and c_to_f(55) == 131",
        "test_text.py::test_collapse_spaces statically imports collapse_spaces from text and observes collapse_spaces('a  b') == 'a b' and collapse_spaces('  hi\\tthere \\n') == 'hi there'",
    ],
    "scope_rule": (
        "Acceptance-criterion SCOPE fields name implementation files only: "
        "units.py for the temperature criterion, text.py for the whitespace "
        "criterion. Test files are never in any task's scope."
    ),
}

WORKERS = {
    "intake": {"worker": "pxx", "problem": OPERATOR_BRIEF, "target_repo": TARGET},
    "plan": {"worker": "pxx", "target_repo": TARGET},
    "code": {"worker": "pxx", "target_repo": TARGET},
    "review": {"worker": "pxx", "target_repo": TARGET},
    "test": {"worker": "real", "target_repo": TARGET},
    "verify": {"worker": "pxx", "target_repo": TARGET},
}

if __name__ == "__main__":
    print(runner.run_all(workers=WORKERS))
