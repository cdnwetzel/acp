# Rung-7 path (b) — sandbox scaffold manifest (prepared 2026-10-12)

Owner authorization: sandbox-only preparation for paths (b)/(c1)/(c2),
including the documented overrides; canonical repo untouched. No waiver
recorded, no resume run.

## Sandbox-only deltas vs canonical (/Users/cwetzel/ai/acp @ 8b1148b)

| File | sha256 | Note |
|---|---|---|
| `acp/pipeline/waiver_proof.py` (override) | `5469082df09dc94a1b12a9e6b54ab146fe037ac569b8e87c35f6d862b7b1d710` | supersession-aware manifest binding (design finding 1) |
| `acp/pipeline/waiver_proof.py.canonical-orig` | `8f454a61ea43a5b9305d31b676b0bce50fc18ed6421540598f1b4aa13893d88d` | byte-identical to canonical, preserved |
| `acp/pipeline/waiver_proof.py.sandbox-diff.patch` | `e1f3ffaafc1928f15d8e6f91b0f8eeb3895b1d20281a05bc371b151ef205dfee` | unified diff of the override |
| `acp/endpoints.json` (override) | `8326263b131f40bae51b30941ccfafbba4175c97a0b143ec4dfb7c87c83a60e7` | verify → `127.0.0.1:11435` supervised forward (operator off home LAN, 172.16.30.x); model unchanged |
| `acp/endpoints.json.canonical-orig` | `6d72585746ac48f6d28e17edd3d0597b01f125b18cdc09c4e39604670aed53cc` | preserved canonical manifest |

Pre-existing challenge scaffold (hash-bound by the ledgered drill_inject,
seq 11): `acp/pipeline/runner.py` (injection hook), `acp/pipeline/drill.py`.
No other pipeline files differ from canonical.

## Override semantics (waiver_proof.py)

The receipt's `diff_manifest_sha256` is valid iff it equals the CODE
completion's artifact hash **or** the `artifact_sha256` of a ledgered
`drill_inject` row whose `supersedes_sha256` chains to that completion
hash. Anything else still fails WAIVER_MANIFEST.

## Preflight evidence (2026-10-12, in-memory against the live ledger)

- Canonical validator + completion → `WAIVER_MANIFEST` on the legitimate
  drill receipt (confirms the conflict this override resolves).
- Sandbox override + completion → `[]` (accepts).
- Bogus manifest (`ff…`) under override → still `WAIVER_MANIFEST`.
- `drill_inject` chaining to a foreign base (`00…`) → does NOT rescue.
- Canonical test suite run against the sandbox pipeline copy
  (`PYTHONPATH=/tmp/acp-rung7-20261012-general/acp`): **359 passed**.

## Verified bindings (recomputed from disk 2026-10-12)

- lifecycle `2957db4c96f9`; chain verify ok, 13 rows, head = seq 12.
- finding: TASK-1 OPEN, finding_sha256
  `cc9ff5811e5e66a50e768ffc43d1fd4a1fbf8e8875f3a7ace36f5a48fb8dfc9e`
- attempt_started (seq 10) `d0d97ddc9d1f656c80a739192600a9f992f41d574b2025054cba78b473394064`
- attempt_failed (seq 12) `7efe36be1a2f7a0d79fa4cae89b978a9b05785756bb2fa02641eada05d5ac01f`
- review.md `f06181ca5d8c20020ffda15df86ffd1b2aa0c45453017a78750143496a0ff8a7`
- injected manifest `048f1a4ac50cc833ea90a873188c36285c2ba743f856c9fa752605798a52c4d0`
  ← chained via seq 11 drill_inject from CODE completion `a8b16005…`
- target clean at DRILL commit `7b44f37b83c6bee164b9a851f7995e74aee57ccf`

## Qualification scope

This path qualifies owner-waiver → advance under a **sandbox-assisted**
configuration (supersession-aware validator + supervised-forward VERIFY).
It does not qualify canonical behavior; promotion of supersession
awareness into canonical evidence code is a separate owner decision.
