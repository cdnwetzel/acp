# review.md

## TASK-1
- issue: c_to_f incorrectly handles negative Celsius values by using `+ 33` instead of `+ 32`, violating the criterion that it must return `c * 9 / 5 + 32` for all numeric inputs, including negatives. — OPEN: The implementation returns a different result for negative inputs, which does not satisfy the specified behavior.

## TASK-2
- issue: none — RESOLVED (diff satisfies the criterion)
