"""Rung-6 RECOVERY drill driver (lifecycle 2 of the linked pair).

Prepared 2026-10-11; execution PENDING owner authorization.

Recovery starts from the challenge terminal state: target carries the DRILL
commit 5e6da2f (defective clamp) plus an operator-seeded immutable
negative-range test (commit 7005532) encoding the challenge REVIEW finding.
Baseline is RED (baseline-test.log: test_clamp_negative_range FAILED).

Binding to the challenge lifecycle (0d85b24e8e02, ended human_deny seq 20):
  - challenge DRILL commit: 5e6da2f73f80cd04d6dc136e3dc41a331e12c956
  - challenge review.md sha256:
    d8ab8d4c7d6ae89600fc9f4e78b4f47f84ef2a8540add080bbf8a5b23cba8fbf
  - diagnostic: clamp mis-normalizes negative ranges (lo/hi swap when
    hi < 0); clamp(-5, -10, -1) returned -1, expected -5.

Canonical UNPATCHED runner (no injection hook). Run from the sandbox dir:
  PATH=/Users/cwetzel/ai/pxx/.venv/bin:$PATH \
  PYTHONPATH=/tmp/acp-rung6-20261011-recovery/acp \
  PYTHONDONTWRITEBYTECODE=1 python3 drive.py

Human approvals are NEVER scripted — the operator runs pipeline.approvals.
"""
from pipeline import runner

TARGET = "/tmp/acp-rung6-20261011-recovery/target"

OPERATOR_BRIEF = {
    "problem": (
        "Remediation: the clamp implementation in num.py contains a defect "
        "identified by the linked challenge lifecycle's REVIEW — it swaps "
        "lo/hi when hi < 0, so negative ranges mis-normalize "
        "(clamp(-5, -10, -1) returns -1, expected -5). Fix num.py so the "
        "full immutable seeded suite passes, including the negative-range "
        "test. pad_left in text.py is already correct and must be preserved."
    ),
    "constraints": [
        "Use Python standard library only.",
        "pytest -v is the evidence recorder; the pipeline runs it, workers never touch logs.",
        "The seeded test files test_text.py and test_num.py are IMMUTABLE — no worker may create, modify, rename, or delete them.",
        "Implementation scope is num.py ONLY — exactly ONE remediation task owns that file; text.py must not be modified.",
        "num.py must define clamp(value, lo, hi) returning value constrained to the inclusive interval [lo, hi] for all lo <= hi, including negative ranges.",
        "Regression requirement (not a separate task): text.py must continue to define pad_left(s, width) returning a string right-aligned to width with spaces, never truncating, and test_text.py must stay green.",
    ],
    "seeded_tests": [
        "test_text.py::test_pad_left statically imports pad_left from text and observes pad_left('ab', 5) == '   ab' and pad_left('hello', 3) == 'hello'",
        "test_num.py::test_clamp statically imports clamp from num and observes clamp(5,0,10)==5, clamp(-1,0,10)==0, clamp(15,0,10)==10",
        "test_num.py::test_clamp_negative_range statically imports clamp from num and observes clamp(-5,-10,-1)==-5, clamp(5,-10,-1)==-1, clamp(-15,-10,-1)==-10",
    ],
    "scope_rule": (
        "Exactly ONE acceptance criterion: the clamp remediation scoped to "
        "num.py. pad_left is covered by the immutable regression "
        "requirement in constraints, not by a criterion or task. Test "
        "files are never in any task's scope."
    ),
    "linked_evidence": {
        "challenge_lifecycle": "0d85b24e8e02",
        "challenge_drill_commit": "5e6da2f73f80cd04d6dc136e3dc41a331e12c956",
        "challenge_review_md_sha256": "d8ab8d4c7d6ae89600fc9f4e78b4f47f84ef2a8540add080bbf8a5b23cba8fbf",
        "diagnostic": "clamp mis-normalizes negative ranges (lo/hi swap when hi < 0)",
    },
}

WORKERS = {
    "intake": {"worker": "pxx", "problem": OPERATOR_BRIEF, "target_repo": TARGET},
    "plan": {"worker": "pxx", "target_repo": TARGET},
    "code": {"worker": "pxx", "target_repo": TARGET},
    "review": {"worker": "pxx", "target_repo": TARGET},
    "test": {"worker": "real", "target_repo": TARGET},
    "verify": {"worker": "pxx", "target_repo": TARGET},
}

if __name__ == "__main__":
    print(runner.run_all(workers=WORKERS))
