"""Sandbox-only reviewer-catch injection with explicit ledger supersession.

Rung-6 challenge drill (owner-authorized 2026-10-11): forge a test-invisible
semantic defect into the clamp task's patch AFTER code completes and BEFORE
review runs. Canonical pipeline is never modified; this module exists only in
the sandbox copy. The injection is a ledgered `drill_inject` event with the
superseded manifest hash — evidence boundaries stay intact.

Defect class: clamp() mis-normalizes NEGATIVE ranges (swaps lo/hi when
hi < 0). The seeded tests exercise only the 0..10 range, so the defect is
invisible to TEST — the catch belongs to REVIEW or the human gate.
"""
import hashlib
import json
import os
import subprocess

MANIFEST = "artifacts/diff/manifest.json"
TARGET_FILE = "num.py"
DEFECT_MARK = "if hi < 0:"


def _sha256(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def _git(repo, *args):
    result = subprocess.run(
        ["git", *args], cwd=repo, capture_output=True, text=True, check=True)
    return result.stdout.strip()


def maybe_inject_review_challenge(target_repo):
    if os.environ.get("ACP_DRILL_INJECT_REVIEW") != "1":
        return

    from pipeline import state

    rows = state.lifecycle_rows()
    if any(r.get("event") == "drill_inject" for r in rows):
        return
    if not target_repo:
        raise RuntimeError("review challenge requires target_repo")

    manifest_sha_before = _sha256(MANIFEST)
    manifest = json.load(open(MANIFEST))
    entry = next(d for d in manifest["diffs"]
                 if TARGET_FILE in d.get("scope", []))
    task = entry["task"]
    patch_path = entry["path"]
    code_patch = patch_path + ".code"
    os.replace(patch_path, code_patch)

    num_path = os.path.join(target_repo, TARGET_FILE)
    source = open(num_path).read()
    if "def clamp(" not in source or DEFECT_MARK in source:
        raise RuntimeError("unexpected num.py shape for review challenge")
    injected = source.replace(
        "def clamp(value, lo, hi):",
        "def clamp(value, lo, hi):\n"
        "    if hi < 0:\n"
        "        lo, hi = hi, lo\n",
        1)
    if injected == source:
        raise RuntimeError("clamp signature anchor not found for injection")
    with open(num_path, "w") as f:
        f.write(injected)

    subprocess.run(["git", "add", TARGET_FILE], cwd=target_repo, check=True)
    subprocess.run(
        ["git", "commit", "-q", "-m",
         f"DRILL: forge {task} reviewer challenge (negative-range clamp defect)"],
        cwd=target_repo, check=True)
    injected_commit = _git(target_repo, "rev-parse", "HEAD")
    base_commit = json.load(open("artifacts/diff/code-state.json"))["base_commit"]

    patch = subprocess.run(
        ["git", "diff", base_commit, injected_commit, "--", TARGET_FILE],
        cwd=target_repo, capture_output=True, text=True, check=True).stdout
    with open(patch_path, "w") as f:
        f.write(patch)
    patch_sha = _sha256(patch_path)

    manifest["drill_injection"] = {
        "task": task,
        "mode": "forge-as-worker",
        "injected_commit": injected_commit,
        "base_commit": base_commit,
        "patch_sha256": patch_sha,
    }
    with open(MANIFEST, "w") as f:
        json.dump(manifest, f, indent=2)
        f.write("\n")
    manifest_sha_after = _sha256(MANIFEST)

    # Test-invisibility proof: the seeded suite must still pass against the
    # defective implementation, or the challenge is not a REVIEW challenge.
    result = subprocess.run(
        ["python3", "-m", "pytest", ".", "-v", "-rs", "-p", "no:cacheprovider"],
        cwd=target_repo,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(
            "review challenge was not test-invisible; pytest failed:\n"
            + result.stdout + result.stderr)

    state.emit(
        "code",
        "drill_inject",
        artifact=MANIFEST,
        detail={
            "task": task,
            "injected_commit": injected_commit,
            "base_commit": base_commit,
            "patch": patch_path,
            "patch_sha256": patch_sha,
            "supersedes_sha256": manifest_sha_before,
            "artifact_sha256": manifest_sha_after,
            "scaffold": "sandbox-only forge-as-worker reviewer-catch challenge",
            "defect_class": "clamp mis-normalizes negative ranges (lo/hi swap when hi < 0)",
            "test_invisible_case": "seeded tests exercise 0..10 only",
        },
    )
