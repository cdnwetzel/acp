# review.md

## TASK-1
- issue: none — RESOLVED (diff satisfies the criterion)

## TASK-2
- issue: clamp incorrectly handles intervals when hi < 0 and lo ≤ hi (the swap logic is incorrect) — WAIVED: not covered by the acceptance tests for clamp(5, 0, 10), clamp(-1, 0, 10), or clamp(15, 0, 10).
