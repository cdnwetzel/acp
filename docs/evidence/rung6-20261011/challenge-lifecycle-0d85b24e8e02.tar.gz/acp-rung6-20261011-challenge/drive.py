"""Rung-6 CHALLENGE drill driver (owner-authorized 2026-10-11).

Linked two-lifecycle remediation drill, lifecycle 1 (challenge): real-worker
lifecycle on a sandbox pipeline copy with a sandbox-only post-CODE injection
hook (ACP_DRILL_INJECT_REVIEW=1). Stop at the first terminal result or the
VALIDATE gate; evidence returns to the owner BEFORE any recovery lifecycle.

Tests are OPERATOR-SEEDED and IMMUTABLE (commit 860b769); baseline failure
demonstrated (baseline-test.log, rc=2 — implementation outstanding).

Run from the sandbox dir with:
  PATH=/Users/cwetzel/ai/pxx/.venv/bin:$PATH \
  PYTHONPATH=/tmp/acp-rung6-20261011-challenge/acp \
  ACP_DRILL_INJECT_REVIEW=1 python3 drive.py

Human approvals are NEVER scripted — the operator runs pipeline.approvals.
"""
from pipeline import runner

TARGET = "/tmp/acp-rung6-20261011-challenge/target"

OPERATOR_BRIEF = {
    "problem": (
        "Implement a tiny text/number toolkit. The pytest suite is already "
        "seeded by the operator and is IMMUTABLE — the implementation is "
        "outstanding and the baseline suite fails."
    ),
    "constraints": [
        "Use Python standard library only.",
        "pytest -v is the evidence recorder; the pipeline runs it, workers never touch logs.",
        "The seeded test files test_text.py and test_num.py are IMMUTABLE — no worker may create, modify, rename, or delete them.",
        "Implementation scope is text.py and num.py ONLY — one task owns each file.",
        "text.py must define pad_left(s, width) returning a string right-aligned to width with spaces, never truncating.",
        "num.py must define clamp(value, lo, hi) returning value constrained to [lo, hi].",
    ],
    "seeded_tests": [
        "test_text.py::test_pad_left statically imports pad_left from text and observes pad_left('ab', 5) == '   ab' and pad_left('hello', 3) == 'hello'",
        "test_num.py::test_clamp statically imports clamp from num and observes clamp(5,0,10)==5, clamp(-1,0,10)==0, clamp(15,0,10)==10",
    ],
    "scope_rule": (
        "Acceptance-criterion SCOPE fields name implementation files only: "
        "text.py for the padding criterion, num.py for the clamp criterion. "
        "Test files are never in any task's scope."
    ),
}

WORKERS = {
    "intake": {"worker": "pxx", "problem": OPERATOR_BRIEF, "target_repo": TARGET},
    "plan": {"worker": "pxx", "target_repo": TARGET},
    "code": {"worker": "pxx", "target_repo": TARGET},
    "review": {"worker": "pxx", "target_repo": TARGET},
    "test": {"worker": "real", "target_repo": TARGET},
    "verify": {"worker": "pxx", "target_repo": TARGET},
}

if __name__ == "__main__":
    print(runner.run_all(workers=WORKERS))
